# Relay local edition — verification report

Date: 11 November 2026. Release: 1.0.0. This is evidence for a local pilot, not a production-safety certification.

## Automated regression checks

25 tests pass; see test-results.txt and the reproducible tests/ directory.

Coverage includes strict filename dates, negative stock, string identifiers, Excel serial dates, mixed DC values, within-file duplicates and conflicts, same-day files and multiple departments, canonical regions/sites, regional rankings, distinct DC quantity and global conflicts, selected-day YTD sums, zero LY growth, coverage-sensitive resolution, new/continuing/returning episodes, missing reporting days, operational-filter suppression, explicit comparisons and a 100-date / 100,000-observation analysis.

IndexedDB adapter tests (fake-indexeddb) cover multi-file ingestion, duplicate rejection, explicit overlap conflict choices, historical retention, independent actions, immutable snapshots, complete backups including original workbooks, checksum rejection, restore equivalence, failed restore preservation, transaction-abort rollback, source replacement and preservation of overlapping provenance.

The actual supplied workbook was parsed: 781 observations, three departments and 11 nonblocking validation notes.

## Chromium browser acceptance checks

- Actual workbook uploaded, reviewed and committed using client-side parsing/IndexedDB.
- Command Centre: 781 instances, 160 articles, 76 stores, 14 regions.
- Positive reported DC stock: 289 article–store instances; 104 unique articles.
- Atlantic region filter: 46 instances, 27 articles, five stores.
- Browser reload and closing/reopening the application tab retained the original counts.
- Snapshot saved, included in the full backup, and preserved by restore.
- Full backup downloaded and selected for restore; checksum verification showed one source file, 781 observations and one snapshot. Confirmed restore completed, and dashboard counts remained unchanged.
- Excel export inspected: 781 data rows plus Report context worksheet; 76 distinct stores.
- CSV export inspected: 781 data rows.
- Executive PDF generated and inspected: two paginated pages after limiting intervention detail to the top 20. Header includes report date, generation timestamp, filters and coverage/methodology notes.
- SVG chart downloaded. PNG chart downloaded and visually inspected (1262 × 722). Dashboard PNG downloaded (2124 × 5046).
- Final browser tests used the standalone static production build via the temporary development-preview origin, not the Windows executable.

## Launcher and build checks

- TypeScript no-emit check passes.
- Standalone Vite production build passes; fonts, parsing, chart and export libraries bundled locally.
- Windows x64 executable cross-compiled using Go 1.24.2; Linux x64 executable compiled and executed.
- Linux launcher smoke checks: index/assets/guide served; restrictive CSP set; POST rejected; foreign Origin, Host and cross-site requests rejected. The server binds only to 127.0.0.1 and contains no operational-data API.
- Source inspection: no network fetch calls or external HTTP URLs in the application data adapter, export module, browser entry or CSS. Local static assets are loaded from the same origin. CSP further restricts external requests.

## Not verified here

Physical Windows execution, Microsoft Edge, OS/browser-process restart, deliberate device network disconnection, power-loss recovery, browser quota exhaustion, profile deletion without backup, target-device performance, unsigned-executable approval, corporate security review and browser-extension access. The application bundles all runtime dependencies, but offline acceptance on the intended desktop is still required.

No remote production deployment was made. The temporary preview and installed local app have different origins and separate IndexedDB datasets. No source workbook or test dataset is included in the distributed application.
