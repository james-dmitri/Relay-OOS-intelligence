import urllib.request,urllib.error,re,subprocess,time,sys
proc=subprocess.Popen([sys.argv[1],'--no-browser'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
try:
 time.sleep(.3)
 base='http://127.0.0.1:47831/'
 r=urllib.request.urlopen(base);text=r.read().decode();assert r.status==200;assert "default-src 'self'" in r.headers['Content-Security-Policy'];paths=re.findall(r'(?:src|href)="(\./assets/[^\"]+)"',text)
 for p in paths:assert urllib.request.urlopen(base+p).status==200
 assert urllib.request.urlopen(base+'guide.html').status==200
 for method,headers,expected in [('POST',{},405),('GET',{'Origin':'https://example.com'},403),('GET',{'Host':'example.com'},403),('GET',{'Sec-Fetch-Site':'cross-site'},403)]:
  try:urllib.request.urlopen(urllib.request.Request(base,method=method,headers=headers));raise AssertionError('Unexpected access')
  except urllib.error.HTTPError as e:assert e.code==expected,(e.code,expected)
 print('PASS: launcher index, assets, guide, CSP, method/Origin/Host/cross-site rejection')
finally:
 proc.terminate();proc.wait(timeout=5)
