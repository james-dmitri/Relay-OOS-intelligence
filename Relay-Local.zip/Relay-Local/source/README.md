# Relay local edition — build and architecture

`app/page.tsx` contains the React workspaces. `lib/analytics.mjs` is a pure analytical engine. `lib/local-store.mjs` handles IndexedDB, Excel parsing, transactions, backups and snapshots. `lib/export.ts` generates reports locally. `local/main.tsx` and `vite.local.config.ts` build the standalone browser app. `launcher/main.go` embeds the static assets and serves them only on 127.0.0.1. No operational data is sent to the launcher.

## Build from source

Use Node.js 22+ and npm. Initial installation requires internet; running the built application does not.

```
npm ci
npm test
npm run typecheck
npm run build
npm run dev
```

`out/` contains the static browser build. The development origin has separate IndexedDB storage from the packaged application's fixed address. Transfer records with full backup/restore.

## Portable executables

Use Go 1.24+ from the official distribution. No Go module dependencies are needed. Copy `out/` contents into `launcher/web/`, then run in `launcher/`:

```
CGO_ENABLED=0 GOOS=windows GOARCH=amd64 go build -buildvcs=false -trimpath -ldflags="-s -w" -o Relay-Windows.exe .
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -buildvcs=false -trimpath -ldflags="-s -w" -o Relay-Linux .
```

On PowerShell set the same variables with `$env:GOOS='windows'`, `$env:GOARCH='amd64'`, `$env:CGO_ENABLED='0'`, then run `go build`. All browser assets are embedded. The fixed origin is `http://127.0.0.1:47831/`; do not change it in upgrades without a migration plan.

## Data contract

IndexedDB name: relay-oos-intelligence-local-v1; schema version 1. Stores: files, observations, stages, coverage, settings, actions, audit, snapshots. Original workbooks are ArrayBuffers. Source data is never included in builds.

A committed import updates all rows, file metadata, replacement status, coverage reset and audit in one transaction. Staged previews do not affect metrics. Winners are selected by reporting date + normalised Site + Article. Explicit conflict decisions control acceptance. Identical overlap retains provenance without increasing analytical counts.

Restore checks SHA-256 integrity, source file hashes, IDs and references before atomically replacing all stores. Validation failure does not mutate data. Transaction failure rolls back. Export backups outside the browser. Future changes must explicitly migrate IndexedDB and version the backup format.

The analytical engine is independent of storage. A future approved SQLite/PostgreSQL adapter can implement the localApi contract and reuse the calculations. No implemented feature needs a backend; SQLite is not bundled. Do not expose the launcher as a multi-user network service.

## Security and validation boundaries

CSP restricts requests to the local origin. Fonts and dependencies are bundled. The launcher binds only to loopback, rejects cross-site Origin/Host requests and supports only GET/HEAD. There is no operational-data HTTP API, telemetry or AI call. This does not protect against malware, privileged extensions or another person using the same browser profile.

See USER_GUIDE.md, TEST_REPORT.md and test-results.txt for known limitations and desktop acceptance requirements. The Windows binary is cross-compiled, unsigned and not executed on a Windows desktop here. Do not call it enterprise production-safe without target-device and organisational review.
