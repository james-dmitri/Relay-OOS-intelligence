module relay-local-launcher

go 1.24
