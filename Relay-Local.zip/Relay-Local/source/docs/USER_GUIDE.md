# Relay | OOS Intelligence — local edition 1.0

## Start on Windows

1. Extract the complete Relay-Local folder from the ZIP into a permanent folder, for example Documents/Relay. Do not run from inside the ZIP.
2. Double-click **Relay-Windows.exe**. A small local launcher window remains open and your default browser opens.
3. Use Microsoft Edge or Google Chrome. If a different browser opens, paste **http://127.0.0.1:47831/** into Edge or Chrome.
4. Keep the launcher window open while using Relay. Close it when finished. Start it again tomorrow the same way.

No Node.js, Python, database service, cloud account, subscription or internet connection is needed for the packaged application. The launcher is unsigned. If company application controls block it, request IT approval; do not bypass your organisation's security policy. The Windows executable was cross-compiled, not executed on a Windows desktop in this build environment.

**Use the exact same address and browser profile every day.** `localhost`, another port, another browser, Guest/InPrivate/Incognito mode and the development preview have separate storage. The fixed local address is part of the persistence design. An upgrade of the executable preserves the same IndexedDB database and address. Always back up before upgrading.

## First report and daily workflow

Open Uploads & Data and choose one or more `.xlsx` files. Relay reads the CLEAR worksheet locally. Both `G CLEAR 23.10.2026.xlsx` and `T CLEAR 20261024.xlsx` are supported. Departments come from the worksheet, never the filename prefix.

Review the row count, validation notes and first 30 observations. Missing identifiers, invalid filenames, missing columns and conflicting duplicates inside one workbook block acceptance. Correct the source and import again. Non-date order text is retained and flagged. Positive or invalid store stock is retained but excluded from OOS metrics.

Press **Commit report** for each accepted workbook. The complete import commits in one IndexedDB transaction; a failed write does not leave half of a file active. Identical fingerprints are rejected. Identical overlapping observations count once. Conflicting overlaps require keeping existing or using incoming values for that file. To correct a previous file, select it in the replacement field before committing; its original bytes remain archived.

Open Command Centre. The latest reporting day is the default. Select regions, departments, stores, articles and additional filters. Top article rankings recalculate within those selections. A trend range changes historical charts; current KPIs remain a single-day snapshot. Select a comparison date in Filters when needed.

Review DC & Orders for numeric supply indicators. “direct” is a classification, not zero inventory. Per-article DC quantities are never summed across stores; conflicting reports remain visibly unresolved. YTD values are summed across unique stores on one date only, never across historical dates.

Use Priority & Actions to record an owner, status, action date, notes and outcome. Actions persist separately from imports. Relay does not infer that an intervention caused a subsequent improvement.

## Coverage and recurrence

An OOS-only file cannot independently prove that a missing observation recovered. Under Uploads & Data, attest coverage only when all expected files, departments and the complete promotional article–store population are included. Record supporting evidence and a promotion scope ID. Reuse the ID only for an unchanged comparable promotion universe. A new import resets that day's attestation.

Without matching complete coverage on both comparison dates, absent pairs are **unknown**, and returning observations are provisional. “Newly observed” means first seen in the available history, not the true start of the stockout. Persistence counts consecutive observed reporting dates, not calendar days. Missing dates are never manufactured as zero.

## Reporting

Report Studio generates PDF briefings with paginated data tables, XLSX workbooks with a context sheet, CSV data and dashboard images. Individual panels have PNG and SVG export controls. Excel/CSV contain actual source measures and calculated fields. Article Intelligence also exports full article history; do not sum cumulative YTD values across its dates.

Save a named snapshot in History & Snapshots. The analytical payload, filters and methodology version are frozen. Reopening a historical date instead recalculates using current data and methodology. Open a saved snapshot, then use Report Studio to export its frozen results. The application distinguishes these states explicitly.

## Full backup — essential

1. Go to Settings & Methodology → Backup, recovery & local storage.
2. Choose **Download full backup** after each important import or day's work.
3. Store the JSON file in an approved, protected folder, ideally with a second approved copy.
4. Keep at least the last few dated versions. The filename may receive a browser suffix for multiple downloads on the same day.

The full backup includes accepted and replaced source workbooks, original and cleaned observations, pending previews, coverage attestations, settings, actions, audit history and immutable snapshots. A SHA-256 checksum protects accidental-integrity checking, and each original workbook's fingerprint is verified during restore. This is not an authenticity signature or encryption. Treat backups as confidential company data.

**Request persistent storage** asks the browser to protect local data from automatic eviction. The browser can refuse. Persistent storage does not protect against deliberate site-data clearing, profile deletion, device failure or private-browsing cleanup. Backup files are the recovery mechanism.

## Restore and move to another computer

1. Start Relay at the normal local address on the target computer/browser profile.
2. If it contains valuable data, download its full backup first.
3. Select **Restore from backup** and choose a Relay JSON backup.
4. Relay verifies format, checksum, source-file hashes, identifiers and references, then shows counts for review.
5. Confirm replacement. Every store is restored in one transaction. Failed validation leaves existing data unchanged.
6. Check the latest date, files, KPI counts, actions and snapshots. Download a new backup after a successful restore.

Clearing a browser profile does not delete exported backup files. If the profile is lost and no backup exists, Relay cannot recover the data. Restoring is a deliberate full replacement, not a merge.

## Data handling

All workbook parsing, transformation, analysis and report generation occurs locally in JavaScript. No workbook or observation is posted to the launcher, a cloud database, AI service, analytics service or telemetry endpoint. Fonts, scripts and export libraries ship inside the executable. Content Security Policy restricts requests to the same local origin. The launcher binds only to 127.0.0.1, rejects nonlocal hosts and cross-origin requests, serves GET/HEAD only and has no data-write API.

This is a single-user browser workspace, not a multi-user secure intranet. Relay does not encrypt IndexedDB or exported reports. Protection depends on the Windows/browser profile, device encryption, access controls and company policy. Browser extensions with sufficient permissions may access page data. Obtain normal company approval before routine use with confidential reports.

## Scope and remaining work

This is a working local release, not a claim of production security certification. It supports all 12 navigation workspaces, local imports, deduplication, explicit conflicts, coverage, recurrence, DC and YTD measures, actions, reports and snapshots.

Known limits and features not fully implemented:

- Maximum 15 MB compressed workbook, 80 MB expanded archive, 10,000 observations per file, 100,000 active historical observations in this release. Full backups may need considerable memory because they include source bytes and snapshots.
- Analysis currently runs on the browser main thread. Large histories can briefly pause the interface. Million-row history, incremental SQL aggregation, Web Worker processing and automated benchmark enforcement are future scaling work.
- Conflict decisions apply to all overlapping conflicts in one file; a per-observation reconciliation editor is not implemented.
- Matrices show the first 20 articles and 15 regions/stores. Detailed tables are paginated. Full underlying records are exportable.
- Weekly review provides the filtered report-date trend and current operational tables. Automatic calendar-week grouping, configurable weekly definitions and promotion denominators are not implemented. It is not an OOS percentage of the full promotion universe.
- Built-in presets are shortcuts; save your own region/date selection for repeat use. Date ranges apply to trends/history, while current-day KPIs use the selected reporting date.
- PDF templates share a core reporting layout. Fully bespoke report-layout editing, saved report templates, image-based immutable render capture and side-by-side saved-snapshot comparisons are not implemented. Snapshots freeze data and filters; rendering may change after a UI upgrade.
- No authentication/role-management, shared database, scheduled backup, background synchronisation, corporate SSO, managed installer or signed executable is included. These are not required for single-user local operation.
- A SQLite backend is not needed by any implemented feature and is not bundled. The storage adapter is isolated from the analytical engine for a future approved intranet/SQLite implementation.
- Windows execution and Microsoft Edge have not been tested in this Linux environment. Chromium browser workflows and the Linux launcher are tested separately. Browser profile restart, OS-level quotas, power-loss recovery and organisation security review require target-device acceptance testing.

## Local acceptance checklist

Before using Relay as your reporting system of record, test on the intended desktop: import two real dates, verify known totals, close browser and launcher, reopen and check persistence, create a full backup, restore it in a clean browser profile, compare totals/actions/snapshots, then disconnect the network and exercise upload and all exports. Retain existing source reports during the pilot.
